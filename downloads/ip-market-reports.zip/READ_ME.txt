Global IP market report package, research cutoff 2026-10-12.
Open reports/IP_全球市场洞察_离线交互报告.html locally after extraction.
Includes 50-page PDF, one-page summary, offline HTML, Excel, public-source snapshots and audit data.
Original user conversation and original uploaded workbook are excluded; their metadata remain in the source register.
Historical predictive backtesting was NOT executed; metrics are null.
Source cache may contain unsuccessful/unadopted retrievals: only registered sources support the report within their stated scope.
