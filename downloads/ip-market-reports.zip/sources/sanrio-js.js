'use strict';

;(function($){

	/*----------
	IRFooter 読み込み
	----------*/
	$('#js_irfooter_e').load('/en/ir/rs_v3/ir/inc/ir_footer.html', function() {
		setIRFooter();
	});


	/*----------
	IRFooter 開閉
	----------*/
	var setIRFooter = function(){

		var $toggle = $('.js_ir_toggle');
		$toggle.each(function(){
			var $this = $(this);
			var $tgt = $this.find('.js_ir_trigger span');
			var $child = $this.find('.js_ir_tgt');

			$tgt.on('click', function(){
				$tgt.toggleClass('is_open');
				$child.slideToggle('normal');
			});
		});
	}

	/*----------
	タブ切り換え
	----------*/
	var setTab = function(){
		var $target = $('.js_tab');

		$target.each(function(){
			var $this = $(this);
			var $target = $this.find('.js_tab_tab');
			var $child = $this.find('.js_tab_contents');

			$target.on('click', function(){
				var $this = $(this);
				var index = $target.index(this);

				$target.removeClass('is_active');
				$this.addClass('is_active');
				$child.removeClass('is_active');
				$child.eq(index).addClass('is_active');
			});
		});
	}

	/*----------
	 開閉ボックス
	 layout/accordion
	----------*/
	var setAccordion = function(){
		var $target = $('.js_accordion');
		$target.each(function(){
			var $this = $(this);
			var $trigger = $this.find('.js_accordion_parent');

			$trigger.on('click', function(){
				var $child = $trigger.next('.js_accordion_child');

				$trigger.toggleClass('is_active');
				$child.toggleClass('is_active');
			});
		});
	}

	/*----------
	modal
	----------*/
	if ($('.modal_inline').length) {
		$('.modal_inline').modaal({
			type: 'inline'
		});
	}

	/*----------
	// アクセシビリティ対応
	// フォーカスでの移動後、遷移先のコードにtarget="-1"追加
	----------*/
		var setFocus = function(){
		$('.js_anchor').on('click', function (e) {
		e.preventDefault();

		const targetId = $(this).attr('href');
		const $target = $(targetId);

		unkerScroll($target, 500);

		setTimeout(function() {
			$target.attr('tabindex', '-1').focus();
		}, 500); // 500ms後に「スクロール完了」を表示
		});
	}

	/*----------
	 実行
	----------*/
	$(function(){
		setTab();
		setAccordion();
		setFocus();
	});

})(jQuery);
