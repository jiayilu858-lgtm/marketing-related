/**
* EIR Javascript v1.4.10
* DATE: 2023-12-11
*/

const eirCode = '8136';
const uniCodeEir = '20260916';
const uniCodeQir = '20240205';
const uniCodeBr = 'xxxxxxxx';
const eirLanguage = 'en';
const isUnifiedDrawingScriptMode = true;
const isLoadedExtendJsonMode = false;

var eirLevel = '';
var demoLocation = /customer[0-9]*\.pronexus|eol\-test\.com|aspdev|localhost/;
// ロケーションで判定
if (location.protocol == 'file:' || demoLocation.test(location.hostname)) {
	eirLevel = 'demo';
} else {
	eirLevel = 'public';
}
if(location.href.match("#public") || location.href.match("level=public")){
	eirLevel = 'public';
} else if(location.href.match("#demo") || location.href.match("level=demo")) {
	eirLevel = 'demo';
}
const eirUrl = ('https:' == document.location.protocol ? 'https://ssl4' : 'http://v4') + '.eir-parts.net';
if( (document.location.protocol == 'https:' || document.location.protocol == 'http:') && !/aspdev/.test(window.location.host)){
	var eirPass = eirUrl + '/Custom/' + eirLevel + '/v5parts/' + eirCode + '/' + eirLanguage + '/' + uniCodeEir + '/';
	var qirPass = eirUrl + '/Custom/' + eirLevel + '/qir/' + eirCode + '/' + eirLanguage + '/' + uniCodeQir +'/';
}else{
	var eirPass = '/v5parts/' + eirCode + '/' + eirLanguage + '/' + uniCodeEir + '/';
    var qirPass = '/v4qir/' + eirCode + '/' + eirLanguage + '/' + uniCodeQir + '/';
}
var eirPassCore = eirPass + 'core/';
var eirPassApp = eirPass + 'app/';
var eirPassMaterial = eirUrl + '/Custom/public/material/parts/';
var language = eirLanguage;

/**
* JSファイルを直列にロードする
*
* @class scriptLoader
*/
var scriptLoader = {
	// scriptタグのsrcを保持する
	sources: [],

	elmHead: document.getElementsByTagName('head')[0],
	
    /**
    * ロードするJSファイルのパスを追加する
    * 追加した順番にロードされる
    *
    * @method setSrc
    * @param {String} src
    */
	setSrc: function(src){
		this.sources.push(src);
	},

    /**
    * JSファイルのロード処理を実行する
    * 第一引数は全てのファイルが正常に読み込めた場合に実行される
    * 第二引数は全てのファイルが正常に読み込無かった場合に実行される
    * 一度実行されると、このオブジェクトに追加されたJSへのパスは全て破棄される
    *
    * @method load
    * @param {Function} doSuccess
    * @param {Function} doError
    */
	load: function(doSuccess, doError){
		if(this.sources.length === 0){
			if(doSuccess){
				doSuccess();
			}
			return; // 再帰の離脱
		}
		var elmScript = document.createElement('script');
		elmScript.charset = 'utf-8';
		elmScript.src = this.sources.shift();
		this.elmHead.appendChild(elmScript);
		var _self = this;
		elmScript.onload = function(){
			_self.load(doSuccess, doError);
		}

		// エラー時
		elmScript.onerror = doError;
	}
}

setLibrary();
if(bowser.msie && bowser.version <= 8){
	showUnSupportedBrowserMessage();
}

if(!/[0-9A-Z]{4}/.test(eirCode)){
	console.warn('証券コードが設定されていません');
}

function showMaintenanceMessage(){
	var message = '<div><img src="data:image/gif;base64,R0lGODlh6AFEAIAAAP///wAAACH5BAEHAAAALAAAAADoAUQAAAL/hI+py+0Po5y02ouz3rz7D4biSJbmiabqyrbuC8fyTNf2jef6zvf+DwwKh8Si8YhMKpfMpvMJjUqn1Kr1is1qt9yu9wsOi8fksvmMTqvX7Lb7DY/L5/S6/Y73BQD7Pc9/AFgjKMhQCHTokJjYwGiyOOFoECBZcVhp18fXU4jJQgjhiSM6uUC62QIpIXkacZlnuNn6mTD7iIBpK3OqumqjqwAcC+sqO0nZCIrMt2zKfAzYXIobWG3aTBn9LKs5XYudHRgtXWvM7Cjd5xd+Db5O/i2ejgsPTc+Yrb3Mru19/s5KHsB71ZAZFCevXMJ/dDR1Q6VwnDWI8bx1A0XNorNS//3S9aOYUeO6ic4ckrQmUWOwgigVTfsIc5hKhaiwsZyp72TIjjuPsbyoM+bHOBfzGbIpEN+9ffNCmrs2caTTpyuj2vO30qHRdiTz9XooNVlYmFurzuxJkSdGiOrYbWTrj+fPqyDhctTpBqhLu1jfggz7l1qlsVg71e16c2jJvhER730KuCrhszL5ol07EvPNBzHTtpw7GS3khjXxhrbsNKfnqeg2R37VqOfpxahfOj6sunRs3XwV317kVnNhq76t2jauzJxvoSiFaQFbz+fr6H/BoTYsdmFgmkdVHvQZaxw6vdppDkTYve3ac4rEVy7ctCs/6r3hDzX5LGXcfcaJ6f9xzhmA/j02h4ADHohgggouyGCDDj4IYYQSTkjhgL2YpQd3KThHnyVTMUbBehroYuBut5jo4IUa/rHiCcKUGJdfF4iYAYkuohAQhK3AWAJ2QvBIowgG2nhiDDyWYVJZaTEVXUf8MebkZOT4WBw3dAUXX5RHKXPed8G4s55bX2LmESlGaclVed9IySRB+aWHXlTzEcKkfmVheWSG+NV3F5Su1QZXbuRtB+g2gf6JU6GdMPcQd50B+uhqh5kFlqKiyYaoZnsKppxogAmqG6hVTpFkf1SGJ5JpzSEXX4ytJVVdcJz+o1RqoFUWKX1TpqakiZV6hStehkIW5plUzcWeqfv/hYNmbtB0GAV5kVpKWHH3pSqpqyj66GdioTh6q1/TTnpbtsX0eay4wmLbX2CNhiscb4Tq5Sy5V0ir7KjMdTuaaiJyi6Go7fKJoaSlqpsov9ey6uuhIMbrKXKYvnvXoJ1p6q3Dow1LBb7LUsarePjMKZB0JwGsIZ7lcStmymtWnEzCdI3JmnvrMoRzyxUlm+bHcfKTrjHvEGznkzXteR7P0L6xtJF5ksbJ0xVOTXXVVl+NddZab811115/DXbYYnO9aQg7btA0wh7usgKwUhPYAcCv7uDJLLDVOGqPQXtwdo1of3iukancrDcIcqOYQ90W3D1jizdS/MHbBS8OuBp5/yeBMuFsf7t25b54rndR45U8M50SkUVyz0pzfKXKvrqe7FbNimn6s9rp/Nid1MGuDsFKN7nxyWLZXFLSQHMEnchb2n5lfruCDN7vtSMfudCq8lZpop/SNqlwumIKYn0Co/ursuRrbCZx12+MFNGQBj+cTNl/qf75B8NfP/s0jos9uC8dKbomGW1+F0MZQIAnMQLpo1cRO5VankVAWNULWJ8LFAOjR0HDQIxWi1FM5kRywSXNR31aYZaw2pc9A86qZyyT3QgGtZFqmS9op+LMZWyYv9xthl2ZiZ/vNBY+HaILh4yjige/9S/HATFYMbxVDYcBKkIhplZHDMoL+ycZ5rg9Ck0xGthvgmiwQonvT1tE1Bjttyoh4o+HfXni/MqRRM9FMWBkdKIZwce+FX0Qi1+sDgeSFzOK0c5NW5Td7l4Gxm1w8S1cPJ5lHHmfAbZOP/JrzniIV8Tp8SwrrFGi7uY2yZLhB08jY9Ny4ginurjjZJLj3IjSNrZY7qKVsqylLW+Jy1zqcpe87KUvfwnMYApzmMQspjGPicxkKnOZzGymM58JzWhKc5rUrKY1r4nNbGpzm9zkZQEAADs=" width="488" height="68"></div>';
	var area = document.getElementsByClassName('eir');
	for(var i=0, len=area.length; i<len; i++){area[i].innerHTML = message}
}
function showUnSupportedBrowserMessage(){
	var text = 'If this message is displayed, your browser may need to be updated.<br>Please obtain the latest version of the browser to show our site correctly.';
	var allElements = document.getElementsByTagName('*');
	var elm;
	for(var i=0, len=allElements.length; i<len; i++){
		elm = allElements[i];
		if(elm.className === 'eir'){
			elm.innerHTML = text;
			elm.style.color = 'red';
			elm.className += ' unSupportedBrowser';
		}		
	}	
}

function setLibrary(){
/*!
 * Bowser - a browser detector
 * https://github.com/ded/bowser
 * MIT License | (c) Dustin Diaz 2015
 */
!function(e,t,n){typeof module!="undefined"&&module.exports?module.exports=n():typeof define=="function"&&define.amd?define(t,n):e[t]=n()}(this,"bowser",function(){function t(t){function n(e){var n=t.match(e);return n&&n.length>1&&n[1]||""}function r(e){var n=t.match(e);return n&&n.length>1&&n[2]||""}function N(e){switch(e){case"NT":return"NT";case"XP":return"XP";case"NT 5.0":return"2000";case"NT 5.1":return"XP";case"NT 5.2":return"2003";case"NT 6.0":return"Vista";case"NT 6.1":return"7";case"NT 6.2":return"8";case"NT 6.3":return"8.1";case"NT 10.0":return"10";default:return undefined}}var i=n(/(ipod|iphone|ipad)/i).toLowerCase(),s=/like android/i.test(t),o=!s&&/android/i.test(t),u=/nexus\s*[0-6]\s*/i.test(t),a=!u&&/nexus\s*[0-9]+/i.test(t),f=/CrOS/.test(t),l=/silk/i.test(t),c=/sailfish/i.test(t),h=/tizen/i.test(t),p=/(web|hpw)os/i.test(t),d=/windows phone/i.test(t),v=/SamsungBrowser/i.test(t),m=!d&&/windows/i.test(t),g=!i&&!l&&/macintosh/i.test(t),y=!o&&!c&&!h&&!p&&/linux/i.test(t),b=r(/edg([ea]|ios)\/(\d+(\.\d+)?)/i),w=n(/version\/(\d+(\.\d+)?)/i),E=/tablet/i.test(t)&&!/tablet pc/i.test(t),S=!E&&/[^-]mobi/i.test(t),x=/xbox/i.test(t),T;/opera/i.test(t)?T={name:"Opera",opera:e,version:w||n(/(?:opera|opr|opios)[\s\/](\d+(\.\d+)?)/i)}:/opr\/|opios/i.test(t)?T={name:"Opera",opera:e,version:n(/(?:opr|opios)[\s\/](\d+(\.\d+)?)/i)||w}:/SamsungBrowser/i.test(t)?T={name:"Samsung Internet for Android",samsungBrowser:e,version:w||n(/(?:SamsungBrowser)[\s\/](\d+(\.\d+)?)/i)}:/coast/i.test(t)?T={name:"Opera Coast",coast:e,version:w||n(/(?:coast)[\s\/](\d+(\.\d+)?)/i)}:/yabrowser/i.test(t)?T={name:"Yandex Browser",yandexbrowser:e,version:w||n(/(?:yabrowser)[\s\/](\d+(\.\d+)?)/i)}:/ucbrowser/i.test(t)?T={name:"UC Browser",ucbrowser:e,version:n(/(?:ucbrowser)[\s\/](\d+(?:\.\d+)+)/i)}:/mxios/i.test(t)?T={name:"Maxthon",maxthon:e,version:n(/(?:mxios)[\s\/](\d+(?:\.\d+)+)/i)}:/epiphany/i.test(t)?T={name:"Epiphany",epiphany:e,version:n(/(?:epiphany)[\s\/](\d+(?:\.\d+)+)/i)}:/puffin/i.test(t)?T={name:"Puffin",puffin:e,version:n(/(?:puffin)[\s\/](\d+(?:\.\d+)?)/i)}:/sleipnir/i.test(t)?T={name:"Sleipnir",sleipnir:e,version:n(/(?:sleipnir)[\s\/](\d+(?:\.\d+)+)/i)}:/k-meleon/i.test(t)?T={name:"K-Meleon",kMeleon:e,version:n(/(?:k-meleon)[\s\/](\d+(?:\.\d+)+)/i)}:d?(T={name:"Windows Phone",osname:"Windows Phone",windowsphone:e},b?(T.msedge=e,T.version=b):(T.msie=e,T.version=n(/iemobile\/(\d+(\.\d+)?)/i))):/msie|trident/i.test(t)?T={name:"Internet Explorer",msie:e,version:n(/(?:msie |rv:)(\d+(\.\d+)?)/i)}:f?T={name:"Chrome",osname:"Chrome OS",chromeos:e,chromeBook:e,chrome:e,version:n(/(?:chrome|crios|crmo)\/(\d+(\.\d+)?)/i)}:/edg([ea]|ios)/i.test(t)?T={name:"Microsoft Edge",msedge:e,version:b}:/vivaldi/i.test(t)?T={name:"Vivaldi",vivaldi:e,version:n(/vivaldi\/(\d+(\.\d+)?)/i)||w}:c?T={name:"Sailfish",osname:"Sailfish OS",sailfish:e,version:n(/sailfish\s?browser\/(\d+(\.\d+)?)/i)}:/seamonkey\//i.test(t)?T={name:"SeaMonkey",seamonkey:e,version:n(/seamonkey\/(\d+(\.\d+)?)/i)}:/firefox|iceweasel|fxios/i.test(t)?(T={name:"Firefox",firefox:e,version:n(/(?:firefox|iceweasel|fxios)[ \/](\d+(\.\d+)?)/i)},/\((mobile|tablet);[^\)]*rv:[\d\.]+\)/i.test(t)&&(T.firefoxos=e,T.osname="Firefox OS")):l?T={name:"Amazon Silk",silk:e,version:n(/silk\/(\d+(\.\d+)?)/i)}:/phantom/i.test(t)?T={name:"PhantomJS",phantom:e,version:n(/phantomjs\/(\d+(\.\d+)?)/i)}:/slimerjs/i.test(t)?T={name:"SlimerJS",slimer:e,version:n(/slimerjs\/(\d+(\.\d+)?)/i)}:/blackberry|\bbb\d+/i.test(t)||/rim\stablet/i.test(t)?T={name:"BlackBerry",osname:"BlackBerry OS",blackberry:e,version:w||n(/blackberry[\d]+\/(\d+(\.\d+)?)/i)}:p?(T={name:"WebOS",osname:"WebOS",webos:e,version:w||n(/w(?:eb)?osbrowser\/(\d+(\.\d+)?)/i)},/touchpad\//i.test(t)&&(T.touchpad=e)):/bada/i.test(t)?T={name:"Bada",osname:"Bada",bada:e,version:n(/dolfin\/(\d+(\.\d+)?)/i)}:h?T={name:"Tizen",osname:"Tizen",tizen:e,version:n(/(?:tizen\s?)?browser\/(\d+(\.\d+)?)/i)||w}:/qupzilla/i.test(t)?T={name:"QupZilla",qupzilla:e,version:n(/(?:qupzilla)[\s\/](\d+(?:\.\d+)+)/i)||w}:/chromium/i.test(t)?T={name:"Chromium",chromium:e,version:n(/(?:chromium)[\s\/](\d+(?:\.\d+)?)/i)||w}:/chrome|crios|crmo/i.test(t)?T={name:"Chrome",chrome:e,version:n(/(?:chrome|crios|crmo)\/(\d+(\.\d+)?)/i)}:o?T={name:"Android",version:w}:/safari|applewebkit/i.test(t)?(T={name:"Safari",safari:e},w&&(T.version=w)):i?(T={name:i=="iphone"?"iPhone":i=="ipad"?"iPad":"iPod"},w&&(T.version=w)):/googlebot/i.test(t)?T={name:"Googlebot",googlebot:e,version:n(/googlebot\/(\d+(\.\d+))/i)||w}:T={name:n(/^(.*)\/(.*) /),version:r(/^(.*)\/(.*) /)},!T.msedge&&/(apple)?webkit/i.test(t)?(/(apple)?webkit\/537\.36/i.test(t)?(T.name=T.name||"Blink",T.blink=e):(T.name=T.name||"Webkit",T.webkit=e),!T.version&&w&&(T.version=w)):!T.opera&&/gecko\//i.test(t)&&(T.name=T.name||"Gecko",T.gecko=e,T.version=T.version||n(/gecko\/(\d+(\.\d+)?)/i)),!T.windowsphone&&(o||T.silk)?(T.android=e,T.osname="Android"):!T.windowsphone&&i?(T[i]=e,T.ios=e,T.osname="iOS"):g?(T.mac=e,T.osname="macOS"):x?(T.xbox=e,T.osname="Xbox"):m?(T.windows=e,T.osname="Windows"):y&&(T.linux=e,T.osname="Linux");var C="";T.windows?C=N(n(/Windows ((NT|XP)( \d\d?.\d)?)/i)):T.windowsphone?C=n(/windows phone (?:os)?\s?(\d+(\.\d+)*)/i):T.mac?(C=n(/Mac OS X (\d+([_\.\s]\d+)*)/i),C=C.replace(/[_\s]/g,".")):i?(C=n(/os (\d+([_\s]\d+)*) like mac os x/i),C=C.replace(/[_\s]/g,".")):o?C=n(/android[ \/-](\d+(\.\d+)*)/i):T.webos?C=n(/(?:web|hpw)os\/(\d+(\.\d+)*)/i):T.blackberry?C=n(/rim\stablet\sos\s(\d+(\.\d+)*)/i):T.bada?C=n(/bada\/(\d+(\.\d+)*)/i):T.tizen&&(C=n(/tizen[\/\s](\d+(\.\d+)*)/i)),C&&(T.osversion=C);var k=!T.windows&&C.split(".")[0];if(E||a||i=="ipad"||o&&(k==3||k>=4&&!S)||T.silk)T.tablet=e;else if(S||i=="iphone"||i=="ipod"||o||u||T.blackberry||T.webos||T.bada)T.mobile=e;return T.msedge||T.msie&&T.version>=10||T.yandexbrowser&&T.version>=15||T.vivaldi&&T.version>=1||T.chrome&&T.version>=20||T.samsungBrowser&&T.version>=4||T.firefox&&T.version>=20||T.safari&&T.version>=6||T.opera&&T.version>=10||T.ios&&T.osversion&&T.osversion.split(".")[0]>=6||T.blackberry&&T.version>=10.1||T.chromium&&T.version>=20?T.a=e:T.msie&&T.version<10||T.chrome&&T.version<20||T.firefox&&T.version<20||T.safari&&T.version<6||T.opera&&T.version<10||T.ios&&T.osversion&&T.osversion.split(".")[0]<6||T.chromium&&T.version<20?T.c=e:T.x=e,T}function r(e){return e.split(".").length}function i(e,t){var n=[],r;if(Array.prototype.map)return Array.prototype.map.call(e,t);for(r=0;r<e.length;r++)n.push(t(e[r]));return n}function s(e){var t=Math.max(r(e[0]),r(e[1])),n=i(e,function(e){var n=t-r(e);return e+=(new Array(n+1)).join(".0"),i(e.split("."),function(e){return(new Array(20-e.length)).join("0")+e}).reverse()});while(--t>=0){if(n[0][t]>n[1][t])return 1;if(n[0][t]!==n[1][t])return-1;if(t===0)return 0}}function o(e,r,i){var o=n;typeof r=="string"&&(i=r,r=void 0),r===void 0&&(r=!1),i&&(o=t(i));var u=""+o.version;for(var a in e)if(e.hasOwnProperty(a)&&o[a]){if(typeof e[a]!="string")throw new Error("Browser version in the minVersion map should be a string: "+a+": "+String(e));return s([u,e[a]])<0}return r}function u(e,t,n){return!o(e,t,n)}var e=!0,n=t(typeof navigator!="undefined"?navigator.userAgent||"":"");return n.test=function(e){for(var t=0;t<e.length;++t){var r=e[t];if(typeof r=="string"&&r in n)return!0}return!1},n.isUnsupportedBrowser=o,n.compareVersions=s,n.check=u,n._detect=t,n.detect=t,n})
}
